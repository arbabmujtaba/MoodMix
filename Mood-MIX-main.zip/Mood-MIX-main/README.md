This is a basic This is a basic more mix cafe generated app uh that let's you stimulate virtual cafe within your music it use DSP. This is my first app hopefully you like it.
